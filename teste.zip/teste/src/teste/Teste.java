
package teste;

import java.util.Scanner;


public class Teste {

    
    public static void main(String[] args) {
        
        int inv, opc, cand, totalvotos, cand1, cand2, cand3, cand4, nulos, brancos;
        double pcand1, totalcand1, totalcand2, totalcand3, totalcand4, totalnulos, totalbrancos, pcand2, 
	pcand3,pcand4, pnulos, pbrancos, urnas, pinv, totalinv;
        String[] nome = new String[6];
        
        Scanner tec = new Scanner(System.in);
        
       
        totalvotos = 0;
        inv = 0;
        cand1 = 0;
        cand2 = 0;
        cand3 = 0;
        cand4 = 0;
        nulos = 0;
        brancos = 0;
        
        for(int c = 1; c<=6; c++){
            System.out.println("Escolha seu time: ");
            nome[c] = tec.next();
            System.out.println("["+ c +"] - " + nome[c]);
        }
        
        System.out.println(" ################# ");
        System.out.println("  Urna Eletrônica  ");
        System.out.println(" ----------------- ");
        System.out.println(" [0] - Abrir urna ");
        System.out.println(" [9] - Fechar Urna ");
        System.out.println(" ################# ");
        opc = tec.nextInt();
        System.out.println("");
        
        
        /*System.out.println(" [1] - Grêmio");
        System.out.println(" [2] - Internacional ");
        System.out.println(" [3] - São Paulo ");
        System.out.println(" [4] - CAP ");
        System.out.println(" [5] - Brancos ");
        System.out.println(" [6] - Nulos ");*/
        
        do{
            System.out.println("Escolha o numero do seu time: ");
            cand = tec.nextInt();
            
            switch(cand){
                
                case 1:
                    cand1++;
                    break;
                case 2:
                    cand2++;
                    break;
                case 3:
                    cand3++;
                    break;
                case 4:
                    cand4++;
                    break;
                case 5:
                    brancos++;
                    break;
                case 6:
                    nulos++;
                    break;
                default:
                    System.out.println("Número inválido");
                    inv++;
            }
            
            //Contabiliza votos
            totalvotos = cand1 + cand2 + cand3+ cand4+ brancos + nulos + inv;
            totalcand1 = cand1;
            totalcand2 = cand2;
            totalcand3 = cand3;
            totalcand4 = cand4;
            totalnulos = nulos;
            totalbrancos = brancos;
            totalinv = inv;
            //Contabiliza em porcentagem
            pcand1 = (totalcand1*100)/totalvotos;
            pcand2 = (totalcand2*100)/totalvotos;
            pcand3 = (totalcand3*100)/totalvotos;
            pcand4 = (totalcand4*100)/totalvotos;
            pnulos = (totalnulos*100)/totalvotos;
            pbrancos = (totalbrancos*100)/totalvotos;
            pinv = (totalinv *100)/totalvotos;
            urnas = pcand1 + pcand2 + pcand3 + pcand4 + pnulos + pbrancos + pinv;
            
        }while(cand != 9);
        
        System.out.println("----Votação encerrada----");
        System.out.println("Total de votos foram: " + totalvotos);
        System.out.println("Total de votos do Grêmio foi: " + totalcand1 + " e a porcentagem foi: " + Math.round(pcand1)+ "%");
        System.out.println("Total de votos do Inter foi: " + totalcand2 + " e a porcentagem foi: " + Math.round(pcand2)+ "%");
        System.out.println("Total de votos do São Paulo foi: " + totalcand3 + " e a porcentagem foi: " + Math.round(pcand3)+ "%");
        System.out.println("Total de votos do CAP foi: " + totalcand4 + " e a porcentagem foi: " + Math.round(pcand4)+ "%");
        System.out.println("Total de votos nulos foram: " + totalnulos + " e a porcentagem foi: " + Math.round(pnulos)+ "%");
        System.out.println("Total de votos brancos foram: " + totalbrancos + " e a porcentagem foi: " + Math.round(pbrancos)+ "%");
        System.out.println("Total de votos inválidos: " + (totalinv - 1) + " e a porcentagem foi: " + Math.round(pinv)+ "%");
        System.out.println("Total de urnas apuradas: " + urnas + "%");
        System.out.println("");
        System.out.println("--------Rank----------");
        if((pcand1 > pcand2) && (pcand3 > pcand4) && (pcand3 < pcand2)){
            System.out.println("1º - " + Math.round(pcand1) + "%");
            System.out.println("2º - " + Math.round(pcand2)+"%");
            System.out.println("3º - " + Math.round(pcand3)+"%");
            System.out.println("4º - " + Math.round(pcand4)+"%");
            
        }else if((pcand1 > pcand2) && (pcand3 > pcand2) && (pcand4 < pcand2)){
            System.out.println("1º - " + Math.round(pcand1) + "%");
            System.out.println("2º - " + Math.round(pcand3) + "%");
            System.out.println("3º - " + Math.round(pcand2) + "%");
            System.out.println("4º - " + Math.round(pcand4) + "%");
        }  
        
        
    }
    
}
